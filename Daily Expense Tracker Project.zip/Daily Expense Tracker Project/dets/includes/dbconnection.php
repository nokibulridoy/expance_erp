<?php
$con=mysqli_connect("192.168.11.105", "user1", "tmssict123", "expance_erp");
if(mysqli_connect_errno()){
echo "Connection Fail".mysqli_connect_error();
}

  ?>
